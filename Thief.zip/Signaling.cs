﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Signaling : MonoBehaviour
{
    [SerializeField] private UnityEvent _reached = new UnityEvent();
    [SerializeField] private float currStrength;
    [SerializeField] private float maxStrength;
    [SerializeField] private float recoveryRate;
    [SerializeField] private bool getThief = false;
    [SerializeField] private bool changeVollume = false;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent<Thief>(out Thief thief))
        {
            if (getThief == false && changeVollume == false)
            {
                _reached?.Invoke();
                getThief = true; 
                changeVollume = true;
            }
        }

        if (getThief == true)
        {
            changeVollume = true;
        }

        if (changeVollume == true)
        {
            maxStrength = AudioListener.volume = 1;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        StartCoroutine(ChangingVolume());
    }

    private IEnumerator ChangingVolume()
    {
        var waitForOneSeconds = new WaitForSeconds(1f);

        changeVollume = false;
        currStrength = Mathf.MoveTowards(currStrength, maxStrength, recoveryRate * Time.deltaTime);
        AudioListener.volume = currStrength;

        yield return waitForOneSeconds;
    }
}