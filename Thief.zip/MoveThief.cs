﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveThief : MonoBehaviour
{
    [SerializeField] private float _speed;

    void Update()
    {
        if (Input.GetKey(KeyCode.D))
        {
            GetComponent<Animator>().SetBool("Run 2", false);
            GetComponent<Animator>().SetBool("Stop", false);
            transform.Translate(_speed * Time.deltaTime, 0, 0);
            GetComponent<Animator>().SetBool("Run 1", true);
        }

        if (Input.GetKey(KeyCode.A))
        {
            GetComponent<Animator>().SetBool("Run 1", false);
            GetComponent<Animator>().SetBool("Stop", false);
            transform.Translate(_speed * Time.deltaTime * -1, 0, 0);
            GetComponent<Animator>().SetBool("Run 2", true);
        }

        if (Input.GetKey(KeyCode.S))
        {
            GetComponent<Animator>().SetBool("Run 1", false);
            GetComponent<Animator>().SetBool("Run 2", false);
            GetComponent<Animator>().SetBool("Stop", true);
        }
    }
}